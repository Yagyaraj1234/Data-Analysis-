import pandas as pd
import plotly.express as px

# Load preprocessed dataset
df = pd.read_csv(r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\preprocessed_accidents.csv")

# Filter to remove outliers
filtered_df = df[(df['Distance(mi)'] < 10) & (df['Temperature(F)'] > -30) & (df['Temperature(F)'] < 120)]

# Plot scatter plot
fig = px.scatter(
    filtered_df,
    x='Temperature(F)',
    y='Distance(mi)',
    color='Severity',
    title='Temperature vs Distance by Severity',
    labels={'Temperature(F)': 'Temperature (°F)', 'Distance(mi)': 'Accident Distance (mi)', 'Severity': 'Severity Level'},
    opacity=0.6
)
fig.update_traces(marker=dict(size=6))
fig.show()

