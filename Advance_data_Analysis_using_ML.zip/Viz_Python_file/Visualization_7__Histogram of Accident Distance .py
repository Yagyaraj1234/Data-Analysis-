
import pandas as pd
import plotly.express as px

# Load preprocessed data
df = pd.read_csv(r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\preprocessed_accidents.csv")

# Filter out extreme distances to focus on typical cases
df_filtered = df[df['Distance(mi)'] < 10]  # Most accidents are < 10 miles

# Plot histogram
fig = px.histogram(
    df_filtered,
    x='Distance(mi)',
    nbins=40,
    title='Distribution of Accident Distances (Under 10 Miles)',
    labels={'Distance(mi)': 'Distance (miles)'},
    color_discrete_sequence=['steelblue']
)
fig.update_layout(bargap=0.1)
fig.show()


