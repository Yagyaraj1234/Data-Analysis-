import pandas as pd
import plotly.express as px

# Load the preprocessed CSV
df = pd.read_csv(r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\preprocessed_accidents.csv", parse_dates=['Start_Time'])

# Group by month
df['Month'] = df['Start_Time'].dt.to_period('M')
monthly_trend = df['Month'].value_counts().sort_index()
monthly_trend.index = monthly_trend.index.astype(str)

# Plot
fig = px.line(
    x=monthly_trend.index,
    y=monthly_trend.values,
    labels={'x': 'Month', 'y': 'Number of Accidents'},
    title='Monthly Trend of Accidents (2016–2021)',
    markers=True
)
fig.update_traces(line=dict(color='royalblue'))
fig.update_layout(xaxis_tickangle=-45)
fig.show()
