
import pandas as pd
import plotly.express as px

# Load preprocessed data
df = pd.read_csv(r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\preprocessed_accidents.csv")

# Clean and group by weather condition
top_weather = df['Weather_Condition'].value_counts().head(10)

# Plot
fig = px.bar(
    x=top_weather.values,
    y=top_weather.index,
    orientation='h',
    labels={'x': 'Number of Accidents', 'y': 'Weather Condition'},
    title='Top 10 Weather Conditions During Accidents',
    text=top_weather.values,
    color=top_weather.values,
    color_continuous_scale='agsunset'
)
fig.update_layout(yaxis=dict(categoryorder='total ascending'))
fig.show()
