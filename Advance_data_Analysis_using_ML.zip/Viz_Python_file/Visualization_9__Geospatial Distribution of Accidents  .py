import pandas as pd
import plotly.express as px

# Load dataset and filter for map clarity
df = pd.read_csv(r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\preprocessed_accidents.csv")
map_df = df[['Start_Lat', 'Start_Lng', 'City', 'State', 'Severity']].dropna().sample(n=1000, random_state=42)

# Plot geospatial map
fig = px.scatter_geo(
    map_df,
    lat='Start_Lat',
    lon='Start_Lng',
    color='Severity',
    hover_name='City',
    title='Geospatial Distribution of Accidents (Sample of 1000)',
    color_continuous_scale='Bluered',
    opacity=0.6,
    scope='usa'
)
fig.update_layout(height=600)
fig.show()
