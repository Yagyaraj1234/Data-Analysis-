
import pandas as pd
import plotly.express as px  # type: ignore

# Load data
df = pd.read_csv(r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\preprocessed_accidents.csv")
df = df.dropna(subset=['Severity']).drop_duplicates()

# Create interactive bar chart
severity_count = df['Severity'].value_counts().sort_index()
fig = px.bar(
    x=severity_count.index.astype(str),
    y=severity_count.values,
    labels={'x': 'Severity Level', 'y': 'Number of Accidents'},
    title='Accident Severity Distribution (Interactive)',
    text=severity_count.values,
    color=severity_count.index.astype(str),
    color_discrete_sequence=px.colors.sequential.Viridis
)
fig.update_layout(showlegend=False)
fig.show()

