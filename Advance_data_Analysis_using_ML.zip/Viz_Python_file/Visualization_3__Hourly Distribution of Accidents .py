import pandas as pd
import plotly.express as px

# Load preprocessed data
df = pd.read_csv(r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\preprocessed_accidents.csv", parse_dates=['Start_Time'])

# Count accidents by hour
hourly_counts = df['Hour'].value_counts().sort_index()

# Plot interactive bar chart
fig = px.bar(
    x=hourly_counts.index,
    y=hourly_counts.values,
    labels={'x': 'Hour of Day', 'y': 'Number of Accidents'},
    title='Hourly Distribution of Accidents',
    text=hourly_counts.values,
    color=hourly_counts.values,
    color_continuous_scale='Inferno'
)
fig.update_layout(xaxis=dict(dtick=1))
fig.show()