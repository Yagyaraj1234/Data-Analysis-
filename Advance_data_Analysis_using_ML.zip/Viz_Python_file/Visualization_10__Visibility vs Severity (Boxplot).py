import pandas as pd
import plotly.express as px

# Load preprocessed data
df = pd.read_csv(r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\preprocessed_accidents.csv")

# Drop invalid values
filtered_df = df[(df['Visibility(mi)'] > 0) & (df['Visibility(mi)'] < 30)]

# Plot boxplot
fig = px.box(
    filtered_df,
    x="Severity",
    y="Visibility(mi)",
    title="Boxplot: Visibility vs Accident Severity",
    labels={"Visibility(mi)": "Visibility (miles)", "Severity": "Accident Severity"},
    color="Severity"
)
fig.update_traces(quartilemethod="inclusive")  
fig.show()
