import pandas as pd
import plotly.express as px

# Load dataset and filter for mapping
df = pd.read_csv(r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\preprocessed_accidents.csv")

# Sample for performance
map_df = df[['Start_Lat', 'Start_Lng', 'City', 'State', 'Severity']].dropna().sample(n=1000, random_state=42)

# Plot using Mapbox
fig = px.scatter_mapbox(
    map_df,
    lat="Start_Lat",
    lon="Start_Lng",
    color="Severity",
    hover_name="City",
    hover_data=["State"],
    zoom=3,
    height=600,
    color_continuous_scale="RdYlBu",
    title="Mapbox: Geospatial Distribution of Accidents (Sample of 1000)"
)

# Set Mapbox style (use 'open-street-map' to avoid token requirement)
fig.update_layout(mapbox_style="open-street-map")
fig.update_layout(margin={"r":0,"t":40,"l":0,"b":0})
fig.show()



