import pandas as pd
import matplotlib.pyplot as plt

# Load preprocessed data
df = pd.read_csv(r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\preprocessed_accidents.csv")

# Drop invalid values
filtered_df = df[(df['Visibility(mi)'] > 0) & (df['Visibility(mi)'] < 30)]

# Group visibility by severity
grouped_data = [filtered_df[filtered_df['Severity'] == severity]['Visibility(mi)'] for severity in sorted(filtered_df['Severity'].unique())]

# Define colors for each severity level
colors = ['lightblue', 'lightgreen', 'gold', 'salmon']  # Adjust or extend as needed

# Create boxplot
fig, ax = plt.subplots(figsize=(10, 6))
box = ax.boxplot(grouped_data, patch_artist=True, labels=sorted(filtered_df['Severity'].unique()))

# Apply colors
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)

# Add title and labels
ax.set_title("Boxplot: Visibility vs Accident Severity")
ax.set_xlabel("Accident Severity")
ax.set_ylabel("Visibility (miles)")

plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()
