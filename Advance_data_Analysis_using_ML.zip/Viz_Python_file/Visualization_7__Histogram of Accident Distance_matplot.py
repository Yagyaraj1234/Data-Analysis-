import pandas as pd
import matplotlib.pyplot as plt

# Load preprocessed data
df = pd.read_csv(r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\preprocessed_accidents.csv")

# Filter for distances under 10 miles
df_filtered = df[df['Distance(mi)'] < 10]

# Plot histogram
plt.figure(figsize=(10, 6))
plt.hist(df_filtered['Distance(mi)'], bins=40, color='steelblue', edgecolor='black')

# Add labels and title
plt.title('Distribution of Accident Distances (Under 10 Miles)', fontsize=14)
plt.xlabel('Distance (miles)', fontsize=12)
plt.ylabel('Number of Accidents', fontsize=12)
plt.grid(True, linestyle='--', alpha=0.6)

plt.tight_layout()
plt.show()
