import pandas as pd
import plotly.express as px
import seaborn as sns
import matplotlib.pyplot as plt

# Load preprocessed data
df = pd.read_csv(r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\preprocessed_accidents.csv")

# Select relevant numerical features
cols = ['Temperature(F)', 'Humidity(%)', 'Visibility(mi)', 'Wind_Speed(mph)', 'Distance(mi)', 'Severity']
corr_matrix = df[cols].corr().round(2)

# Optional: Save as figure
plt.figure(figsize=(8, 6))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', linewidths=0.5)
plt.title("Correlation Between Environmental Factors and Accident Severity")
plt.tight_layout()
plt.show()