import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load preprocessed dataset
df = pd.read_csv(r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\preprocessed_accidents.csv")

# Filter to remove outliers
filtered_df = df[(df['Distance(mi)'] < 10) & 
                 (df['Temperature(F)'] > -30) & 
                 (df['Temperature(F)'] < 120)]

# Set plot style
sns.set(style="whitegrid")

# Create scatter plot
plt.figure(figsize=(12, 7))
scatter = sns.scatterplot(
    data=filtered_df,
    x='Temperature(F)',
    y='Distance(mi)',
    hue='Severity',
    alpha=0.6,
    palette='viridis',
    s=30  # marker size
)

# Set titles and labels
plt.title('Temperature vs Distance by Severity')
plt.xlabel('Temperature (°F)')
plt.ylabel('Accident Distance (mi)')
plt.legend(title='Severity Level')

plt.tight_layout()
plt.show()
