import pandas as pd
import plotly.express as px

# Load preprocessed data
df = pd.read_csv(r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\preprocessed_accidents.csv")

# Ensure Weekday column exists
if 'Weekday' not in df.columns:
    df['Start_Time'] = pd.to_datetime(df['Start_Time'], errors='coerce')
    df['Weekday'] = df['Start_Time'].dt.day_name()

# Count and order weekdays
weekday_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
weekday_counts = df['Weekday'].value_counts().reindex(weekday_order)

# Plot
fig = px.bar(
    x=weekday_counts.index,
    y=weekday_counts.values,
    labels={'x': 'Day of the Week', 'y': 'Number of Accidents'},
    title='Accident Distribution by Day of the Week',
    text=weekday_counts.values,
    color=weekday_counts.values,
    color_continuous_scale='jet'
)
fig.show()
