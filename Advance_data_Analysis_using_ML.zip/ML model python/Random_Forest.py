import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report

# Define file paths
train_path = r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\Train_and_test\train.csv"
test_path = r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\Train_and_test\test.csv"

# Load train and test datasets
train_df = pd.read_csv(train_path)
test_df = pd.read_csv(test_path)

# Define features and target
features = ['Temperature(F)', 'Humidity(%)', 'Visibility(mi)', 'Wind_Speed(mph)',
            'Distance(mi)', 'Hour', 'Month']
target = 'Severity'

# Drop rows with missing values in required columns
train_df = train_df.dropna(subset=features + [target])
test_df = test_df.dropna(subset=features + [target])

# Extract feature matrix and target vector
X_train = train_df[features]
y_train = train_df[target]
X_test = test_df[features]
y_test = test_df[target]

# Train Random Forest model
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)

# Predict
y_pred = rf_model.predict(X_test)

# Evaluate
print("Random Forest Evaluation Results:")
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred, average='weighted', zero_division=0))
print("Recall:", recall_score(y_test, y_pred, average='weighted', zero_division=0))
print("F1-score:", f1_score(y_test, y_pred, average='weighted', zero_division=0))
print("\nClassification Report:\n", classification_report(y_test, y_pred, zero_division=0))

