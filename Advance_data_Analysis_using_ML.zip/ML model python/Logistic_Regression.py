import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score, f1_score

# Define file paths
train_path = r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\Train_and_test\train.csv"
test_path = r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\Train_and_test\test.csv"

# Load train and test datasets
train_df = pd.read_csv(train_path)
test_df = pd.read_csv(test_path)

# Define features and target column
features = ['Temperature(F)', 'Humidity(%)', 'Visibility(mi)', 'Wind_Speed(mph)',
            'Distance(mi)', 'Hour', 'Month']
target = 'Severity'

# Drop rows with missing values in any of the selected columns
train_df = train_df.dropna(subset=features + [target])
test_df = test_df.dropna(subset=features + [target])

# Extract feature matrix and target vector
X_train = train_df[features]
y_train = train_df[target]
X_test = test_df[features]
y_test = test_df[target]

# Scale the feature data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Initialize and train the Logistic Regression model
lr_model = LogisticRegression(max_iter=1000)
lr_model.fit(X_train_scaled, y_train)

# Predict on test set
y_pred = lr_model.predict(X_test_scaled)

# Print evaluation metrics
print("Logistic Regression Evaluation Results:")
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred, average='weighted', zero_division=0))
print("Recall:", recall_score(y_test, y_pred, average='weighted', zero_division=0))
print("F1-score:", f1_score(y_test, y_pred, average='weighted', zero_division=0))
print("\nClassification Report:\n", classification_report(y_test, y_pred, zero_division=0))
