import pandas as pd
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report

# === File paths ===
train_path = r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\Train_and_test\train.csv"
test_path = r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\Train_and_test\test.csv"

# === Load data ===
train_df = pd.read_csv(train_path)
test_df = pd.read_csv(test_path)

# === Define features and target ===
features = ['Temperature(F)', 'Humidity(%)', 'Visibility(mi)', 'Wind_Speed(mph)',
            'Distance(mi)', 'Hour', 'Month']
target = 'Severity'

# === Drop rows with missing values ===
train_df = train_df.dropna(subset=features + [target])
test_df = test_df.dropna(subset=features + [target])

# === Prepare input/output ===
X_train = train_df[features]
y_train = train_df[target]
X_test = test_df[features]
y_test = test_df[target]

# Map target classes from [1, 2, 3, 4] to [0, 1, 2, 3]
y_train = y_train - 1
y_test = y_test - 1

# === Train XGBoost model ===
xgb_model = XGBClassifier(use_label_encoder=False, eval_metric='mlogloss', random_state=42)
xgb_model.fit(X_train, y_train)

# === Predict and evaluate ===
y_pred = xgb_model.predict(X_test)

print("XGBoost Classifier Evaluation Results:")
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred, average='weighted', zero_division=0))
print("Recall:", recall_score(y_test, y_pred, average='weighted', zero_division=0))
print("F1-score:", f1_score(y_test, y_pred, average='weighted', zero_division=0))
print("\nClassification Report:\n", classification_report(y_test, y_pred, zero_division=0))
