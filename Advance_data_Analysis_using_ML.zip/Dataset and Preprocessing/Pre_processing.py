
import pandas as pd

# Load dataset
csv_path = r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\US_Accidents_March23.csv"
df = pd.read_csv(csv_path, low_memory=False)

# Convert datetime
df['Start_Time'] = pd.to_datetime(df['Start_Time'], errors='coerce')

# Drop missing rows
df = df.dropna(subset=['Start_Lat', 'Start_Lng', 'Weather_Condition', 'Severity'])

# Drop duplicates
df = df.drop_duplicates()

# Keep relevant features
df = df[['Start_Time', 'Severity', 'City', 'State', 'Start_Lat', 'Start_Lng',
         'Temperature(F)', 'Humidity(%)', 'Visibility(mi)', 'Wind_Speed(mph)',
         'Weather_Condition', 'Distance(mi)', 'Traffic_Signal']]

# Feature engineering
df['Hour'] = df['Start_Time'].dt.hour
df['Month'] = df['Start_Time'].dt.month
df['Weekday'] = df['Start_Time'].dt.day_name()

# Clean weather condition text
df['Weather_Condition'] = df['Weather_Condition'].str.strip().str.lower()

# Optional: remove outliers
df = df[df['Distance(mi)'] < 100]

# Save preprocessed version (optional)
output_path = r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\preprocessed_accidents.csv"
df.to_csv(output_path, index=False)

print("Preprocessing complete. Final shape:", df.shape)
