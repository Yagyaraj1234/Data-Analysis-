import pandas as pd
import matplotlib.pyplot as plt

# File path
file_path = r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\Pyspark\average_severity_by_state.csv"

# Load data
df = pd.read_csv(file_path)

# Sort by severity for better visualization
df_sorted = df.sort_values(by="Average_Severity", ascending=False)

# Plotting
plt.figure(figsize=(14, 8))
bars = plt.bar(df_sorted["State"], df_sorted["Average_Severity"], color='skyblue')
plt.xticks(rotation=90)
plt.xlabel("State")
plt.ylabel("Average Accident Severity")
plt.title("Average Accident Severity by State")
plt.tight_layout()

# Show plot
plt.show()
