from pyspark.sql import SparkSession

print("Step 1: Initializing Spark session...")
spark = SparkSession.builder.appName("US_Accidents_Analysis").getOrCreate()

base_path = r"C:/Users/Yagyarajsharma/Desktop/Data Viz/Vizilization python script"
file_path = f"{base_path}/preprocessed_accidents.csv"
output_path = f"{base_path}/average_severity_by_state.csv"

print("Step 2: Reading CSV with inferred schema...")
df = spark.read.csv(file_path, header=True, inferSchema=True)

print("Step 3: Selecting necessary columns...")
# Ensure these columns exist in the CSV file
df = df.select("Severity", "State")

print("Step 4: Dropping nulls in Severity or State...")
df_clean = df.dropna(subset=["Severity", "State"])

print("Step 5: Counting total valid records...")
print(f"Total rows: {df_clean.count()}")

print("Step 6: Calculating average severity by state...")
agg_df = df_clean.groupBy("State") \
                 .avg("Severity") \
                 .withColumnRenamed("avg(Severity)", "Average_Severity") \
                 .orderBy("State")

print("Step 7: Displaying results...")
agg_df.show()

print("Step 8: Saving to CSV ")
agg_df_pd = agg_df.toPandas()
agg_df_pd.to_csv(output_path, index=False)
print("🎉 CSV file saved locally:", output_path)
