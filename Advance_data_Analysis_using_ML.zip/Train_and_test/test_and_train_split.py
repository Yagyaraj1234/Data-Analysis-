import pandas as pd
from sklearn.model_selection import train_test_split
import os

# File paths
input_file = r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\preprocessed_accidents.csv"
output_dir = r"C:\Users\Yagyarajsharma\Desktop\Data Viz\Vizilization python script\Train_and_test"

# Ensure output directory exists
os.makedirs(output_dir, exist_ok=True)

# Load the dataset
df = pd.read_csv(input_file)

# Split into 80% training and 20% test
train_df, test_df = train_test_split(df, test_size=0.2, random_state=42)

# Save the splits
train_file = os.path.join(output_dir, "train.csv")
test_file = os.path.join(output_dir, "test.csv")

train_df.to_csv(train_file, index=False)
test_df.to_csv(test_file, index=False)

print(f"Train and test files saved to:\n{train_file}\n{test_file}")
